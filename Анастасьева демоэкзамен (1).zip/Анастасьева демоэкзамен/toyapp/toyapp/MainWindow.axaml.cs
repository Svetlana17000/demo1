using Avalonia.Controls;
using Avalonia.Interactivity;
using ToyStore.ViewModels;
using System;
using System.Threading.Tasks;

namespace ToyStore
{
    public partial class MainWindow : Window
    {
        private MainWindowViewModel? _viewModel;

        public MainWindow()
        {
            InitializeComponent();
        }

        public MainWindow(User currentUser) : this()
        {
            _viewModel = new MainWindowViewModel(currentUser);
            DataContext = _viewModel;
            this.Title = $"Магазин игрушек - {(_viewModel.CurrentUser.Role == "guest" ? "Гость" : _viewModel.CurrentUser.FullName)}";
        }

        private async void OnAddProductClick(object? sender, RoutedEventArgs e)
        {
            if (_viewModel != null && _viewModel.IsAdmin)
            {
                var addWindow = new ProductEditWindow();
                await addWindow.ShowDialog(this);
                _viewModel.LoadProducts();
                _viewModel.ResetFilters();
            }
        }

        private async void OnAddOrderClick(object? sender, RoutedEventArgs e)
        {
            if (_viewModel != null && _viewModel.IsAdmin)
            {
                var window = new OrderEditWindow();
                await window.ShowDialog(this);
                _viewModel.LoadOrders();
            }
        }

        private void OnLogoutClick(object? sender, RoutedEventArgs e)
        {
            var authWindow = new AuthorizationWindow();
            authWindow.Show();
            this.Close();
        }

        private void OnResetFiltersClick(object? sender, RoutedEventArgs e)
        {
            if (_viewModel != null)
            {
                _viewModel.ResetFilters();
            }
        }

        private void OnOrderSelected(object? sender, Avalonia.Input.PointerPressedEventArgs e)
        {
            if (sender is Border border && border.DataContext is Order order)
            {
                _viewModel.SelectedOrder = order;
            }
        }

        private async void OnEditProductClick(object? sender, RoutedEventArgs e)
        {
            if (_viewModel != null && sender is Button btn && btn.DataContext is Product product)
            {
                var editWindow = new ProductEditWindow(product);
                await editWindow.ShowDialog(this);
                _viewModel.LoadProducts();
                _viewModel.ResetFilters();
            }
        }

        private async void OnDeleteProductClick(object? sender, RoutedEventArgs e)
        {
            if (_viewModel != null && sender is Button btn && btn.DataContext is Product product)
            {
                var result = await ShowConfirmDialog($"Удалить товар {product.Name}?");
                if (result)
                {
                    _viewModel.DeleteProduct(product);
                    _viewModel.ResetFilters();
                }
            }
        }

        private async void OnUpdateStatusClick(object? sender, RoutedEventArgs e)
        {
            if (_viewModel != null && _viewModel.SelectedOrder != null)
            {
                var window = new OrderEditWindow(_viewModel.SelectedOrder);
                await window.ShowDialog(this);
                _viewModel.LoadOrders();
            }
        }

        private async void OnDeleteOrderClick(object? sender, RoutedEventArgs e)
        {
            if (_viewModel != null && _viewModel.SelectedOrder != null)
            {
                var result = await ShowConfirmDialog($"Удалить заказ {_viewModel.SelectedOrder.OrderNumber}?");
                if (result)
                {
                    _viewModel.DeleteOrder();
                }
            }
        }

        private async Task<bool> ShowConfirmDialog(string message)
        {
            var window = new Window
            {
                Title = "Подтверждение",
                Width = 300,
                Height = 150,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Content = new StackPanel
                {
                    Margin = new Avalonia.Thickness(10),
                    Children =
                    {
                        new TextBlock { Text = message, Margin = new Avalonia.Thickness(0, 0, 0, 10), TextWrapping = Avalonia.Media.TextWrapping.Wrap, Foreground = Avalonia.Media.Brushes.Black },
                        new StackPanel
                        {
                            Orientation = Avalonia.Layout.Orientation.Horizontal,
                            HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Center,
                            Spacing = 10,
                            Children =
                            {
                                new Button { Content = "Да", Width = 60, Background = Avalonia.Media.Brushes.LightGreen },
                                new Button { Content = "Нет", Width = 60 }
                            }
                        }
                    }
                }
            };

            var result = false;
            var buttons = ((StackPanel)window.Content).Children[1] as StackPanel;
            ((Button)buttons!.Children[0]).Click += (s, ev) => { result = true; window.Close(); };
            ((Button)buttons.Children[1]).Click += (s, ev) => window.Close();
            
            await window.ShowDialog(this);
            return result;
        }
    }
}