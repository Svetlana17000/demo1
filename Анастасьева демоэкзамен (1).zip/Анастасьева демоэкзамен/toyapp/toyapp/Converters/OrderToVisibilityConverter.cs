using Avalonia.Data.Converters;
using System;
using System.Globalization;

namespace ToyStore.Converters
{
    public class OrderToVisibilityConverter : IValueConverter
    {
        public static readonly OrderToVisibilityConverter Instance = new();
        
        public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            return value != null;
        }

        public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
    
    public class OrderToInverseVisibilityConverter : IValueConverter
    {
        public static readonly OrderToInverseVisibilityConverter Instance = new();
        
        public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            return value == null;
        }

        public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}