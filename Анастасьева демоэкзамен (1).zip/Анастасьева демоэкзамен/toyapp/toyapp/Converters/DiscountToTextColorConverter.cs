using Avalonia.Data.Converters;
using Avalonia.Media;
using System;
using System.Globalization;

namespace ToyStore.Converters
{
    public class DiscountToTextColorConverter : IValueConverter
    {
        public static readonly DiscountToTextColorConverter Instance = new();
        
        public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            if (value is int discount && discount > 17)
            {
                return new SolidColorBrush(Colors.Black);
            }
            return new SolidColorBrush(Colors.Black);
        }

        public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}