using Avalonia.Data.Converters;
using Avalonia.Media;
using System;
using System.Globalization;

namespace ToyStore.Converters
{
    public class StockToColorConverter : IValueConverter
    {
        public static readonly StockToColorConverter Instance = new();
        
        public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            if (value is int stock)
            {
                if (stock <= 0) return new SolidColorBrush(Colors.Red);
                if (stock < 5) return new SolidColorBrush(Colors.Orange);
                return new SolidColorBrush(Colors.Green);
            }
            return new SolidColorBrush(Colors.Gray);
        }

        public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}