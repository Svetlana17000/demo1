using Avalonia.Data.Converters;
using Avalonia.Media.Imaging;
using System;
using System.Globalization;
using System.IO;

namespace ToyStore.Converters
{
    public class StringToImageConverter : IValueConverter
    {
        public static readonly StringToImageConverter Instance = new();
        
        public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            try
            {
                string fileName = value as string;
                
                if (!string.IsNullOrEmpty(fileName))
                {
                    var path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", fileName);
                    if (File.Exists(path))
                    {
                        return new Bitmap(path);
                    }
                }
                
                var noImagePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "no-image.jpg");
                if (File.Exists(noImagePath))
                {
                    return new Bitmap(noImagePath);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка загрузки изображения: {ex.Message}");
            }
            
            return null;
        }

        public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}