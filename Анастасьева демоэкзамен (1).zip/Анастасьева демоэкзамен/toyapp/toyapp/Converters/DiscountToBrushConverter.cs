using Avalonia.Data.Converters;
using Avalonia.Media;
using System;
using System.Globalization;

namespace ToyStore.Converters
{
    public class DiscountToBrushConverter : IValueConverter
    {
        public static readonly DiscountToBrushConverter Instance = new();
        
        public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            if (value is int discount && discount > 17)
            {
                return new SolidColorBrush(Color.Parse("#FFDEAD"));
            }
            return new SolidColorBrush(Colors.White);
        }

        public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}