using System;
using System.Globalization;
using Avalonia.Data.Converters;

namespace ToyStore.Converters
{
    public class PriceToStringConverter : IValueConverter
    {
        public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            if (value is decimal price)
            {
                return $"{price:F2} руб.";
            }
            if (value is int intPrice)
            {
                return $"{intPrice:F2} руб.";
            }
            return "0.00 руб.";
        }

        public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}