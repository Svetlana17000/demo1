using Avalonia.Data.Converters;
using System;
using System.Globalization;

namespace ToyStore.ViewModels
{
    public class DiscountToVisibilityConverter : IValueConverter
    {
        public static readonly DiscountToVisibilityConverter Instance = new();
        
        public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            if (value is int discount && discount > 0)
            {
                return true;
            }
            return false;
        }

        public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}