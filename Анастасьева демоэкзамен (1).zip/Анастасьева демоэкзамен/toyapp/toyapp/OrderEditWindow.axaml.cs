using Avalonia.Controls;
using Avalonia.Interactivity;
using System;
using System.Collections.ObjectModel;
using System.Linq;

namespace ToyStore
{
    public partial class OrderEditWindow : Window
    {
        private readonly ToyStoreDbContext _dbContext;
        private readonly Order? _order;
        private readonly bool _isEdit;
        private ObservableCollection<OrderItemViewModel> _orderItems = new();

        public OrderEditWindow(Order? order = null)
        {
            InitializeComponent();
            _dbContext = new ToyStoreDbContext();
            _order = order;
            _isEdit = order != null;
            
            this.Title = _isEdit ? "Редактирование заказа" : "Добавление заказа";
            
            LoadPickupPoints();
            
            if (_isEdit && _order != null)
            {
                LoadOrderData();
                OrderNumberTextBox.IsReadOnly = true;
            }
            
            OrderItemsList.ItemsSource = _orderItems;
            
            AddProductButton.Click += OnAddProductClick;
            SaveButton.Click += OnSaveClick;
            CancelButton.Click += (s, e) => Close();
        }

        private void LoadPickupPoints()
        {
            var points = _dbContext.PickupPoints.ToList();
            PickupPointComboBox.ItemsSource = points;
            if (points.Any())
            {
                PickupPointComboBox.SelectedIndex = 0;
            }
        }

        private void LoadOrderData()
        {
            if (_order == null) return;
            
            OrderNumberTextBox.Text = _order.OrderNumber;
            ClientNameTextBox.Text = _order.ClientFullName;
            OrderDatePicker.SelectedDate = _order.OrderDate;
            DeliveryDatePicker.SelectedDate = _order.DeliveryDate;
            PickupCodeTextBox.Text = _order.PickupCode;
            
            for (int i = 0; i < StatusComboBox.Items.Count; i++)
            {
                var item = StatusComboBox.Items[i] as ComboBoxItem;
                if (item != null && item.Content?.ToString() == _order.Status)
                {
                    StatusComboBox.SelectedIndex = i;
                    break;
                }
            }
            
            if (_order.PickupPoint != null)
            {
                var point = PickupPointComboBox.Items.Cast<PickupPoint>().FirstOrDefault(p => p.Id == _order.PickupPoint.Id);
                if (point != null)
                {
                    PickupPointComboBox.SelectedItem = point;
                }
            }
            
            var items = from oi in _dbContext.OrderItems
                        join p in _dbContext.Products on oi.ProductArticle equals p.Article
                        where oi.OrderId == _order.Id
                        select new OrderItemViewModel
                        {
                            ProductArticle = p.Article,
                            ProductName = p.Name,
                            Quantity = oi.Quantity
                        };
            
            _orderItems.Clear();
            foreach (var item in items)
            {
                _orderItems.Add(item);
            }
        }

        private async void OnAddProductClick(object? sender, RoutedEventArgs e)
        {
            var productWindow = new ProductSelectorWindow(_dbContext);
            await productWindow.ShowDialog(this);
            
            if (productWindow.SelectedProduct != null && productWindow.SelectedQuantity > 0)
            {
                var existingItem = _orderItems.FirstOrDefault(i => i.ProductArticle == productWindow.SelectedProduct.Article);
                if (existingItem != null)
                {
                    existingItem.Quantity += productWindow.SelectedQuantity;
                }
                else
                {
                    _orderItems.Add(new OrderItemViewModel
                    {
                        ProductArticle = productWindow.SelectedProduct.Article,
                        ProductName = productWindow.SelectedProduct.Name,
                        Quantity = productWindow.SelectedQuantity
                    });
                }
                
                RefreshItemsList();
            }
        }

        private void RefreshItemsList()
        {
            OrderItemsList.ItemsSource = null;
            OrderItemsList.ItemsSource = _orderItems;
        }

        private void OnRemoveProductClick(object? sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.DataContext is OrderItemViewModel item)
            {
                _orderItems.Remove(item);
                RefreshItemsList();
            }
        }

        private async void OnSaveClick(object? sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(OrderNumberTextBox.Text))
                {
                    ShowError("Введите номер заказа");
                    return;
                }
                if (string.IsNullOrWhiteSpace(ClientNameTextBox.Text))
                {
                    ShowError("Введите ФИО клиента");
                    return;
                }
                if (OrderDatePicker.SelectedDate == null)
                {
                    ShowError("Выберите дату заказа");
                    return;
                }
                if (DeliveryDatePicker.SelectedDate == null)
                {
                    ShowError("Выберите дату доставки");
                    return;
                }
                if (_orderItems.Count == 0)
                {
                    ShowError("Добавьте хотя бы один товар");
                    return;
                }
                
                var selectedStatus = (StatusComboBox.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Новый";
                var selectedPickupPoint = PickupPointComboBox.SelectedItem as PickupPoint;
                var pickupPointId = selectedPickupPoint?.Id;
                
                if (_isEdit && _order != null)
                {
                    var existingOrder = await _dbContext.Orders.FindAsync(_order.Id);
                    if (existingOrder != null)
                    {
                        existingOrder.ClientFullName = ClientNameTextBox.Text;
                        existingOrder.OrderDate = OrderDatePicker.SelectedDate.Value.DateTime;
                        existingOrder.DeliveryDate = DeliveryDatePicker.SelectedDate.Value.DateTime;
                        existingOrder.PickupCode = PickupCodeTextBox.Text;
                        existingOrder.Status = selectedStatus;
                        existingOrder.PickupPointId = pickupPointId;
                        
                        var oldItems = _dbContext.OrderItems.Where(oi => oi.OrderId == existingOrder.Id);
                        _dbContext.OrderItems.RemoveRange(oldItems);
                        
                        foreach (var item in _orderItems)
                        {
                            _dbContext.OrderItems.Add(new OrderItem
                            {
                                OrderId = existingOrder.Id,
                                ProductArticle = item.ProductArticle,
                                Quantity = item.Quantity
                            });
                        }
                        
                        _dbContext.Orders.Update(existingOrder);
                        await _dbContext.SaveChangesAsync();
                    }
                }
                else
                {
                    var newOrder = new Order
                    {
                        OrderNumber = OrderNumberTextBox.Text,
                        ClientFullName = ClientNameTextBox.Text,
                        OrderDate = OrderDatePicker.SelectedDate.Value.DateTime,
                        DeliveryDate = DeliveryDatePicker.SelectedDate.Value.DateTime,
                        PickupCode = PickupCodeTextBox.Text,
                        Status = selectedStatus,
                        PickupPointId = pickupPointId
                    };
                    
                    _dbContext.Orders.Add(newOrder);
                    await _dbContext.SaveChangesAsync();
                    
                    foreach (var item in _orderItems)
                    {
                        _dbContext.OrderItems.Add(new OrderItem
                        {
                            OrderId = newOrder.Id,
                            ProductArticle = item.ProductArticle,
                            Quantity = item.Quantity
                        });
                    }
                    
                    await _dbContext.SaveChangesAsync();
                }
                
                Close();
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка: {ex.Message}");
            }
        }

        private void ShowError(string message)
        {
            ErrorTextBlock.Text = message;
            ErrorTextBlock.IsVisible = true;
        }
    }

    public class OrderItemViewModel
    {
        public string ProductArticle { get; set; } = "";
        public string ProductName { get; set; } = "";
        public int Quantity { get; set; }
        public string QuantityText => $"{Quantity} шт.";
    }
}