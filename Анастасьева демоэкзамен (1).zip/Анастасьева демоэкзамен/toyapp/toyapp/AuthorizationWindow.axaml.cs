using Avalonia.Controls;
using System;
using System.Linq;

namespace ToyStore
{
    public partial class AuthorizationWindow : Window
    {
        private readonly ToyStoreDbContext _dbContext;

        public AuthorizationWindow()
        {
            InitializeComponent();
            _dbContext = new ToyStoreDbContext();
            if (LoginButton != null) LoginButton.Click += OnLoginClick;
            if (GuestButton != null) GuestButton.Click += OnGuestClick;
        }

        private void OnLoginClick(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
        {
            if (ErrorTextBlock != null) ErrorTextBlock.IsVisible = false;
            
            var login = LoginTextBox?.Text?.Trim();
            var password = PasswordTextBox?.Text?.Trim();
            
            if (string.IsNullOrWhiteSpace(login))
            {
                ShowError("Введите логин");
                return;
            }
            if (string.IsNullOrWhiteSpace(password))
            {
                ShowError("Введите пароль");
                return;
            }

            try
            {
                var user = _dbContext.Users.FirstOrDefault(u => u.Login == login);
                if (user == null)
                {
                    ShowError("Пользователь не найден");
                    return;
                }
                if (user.Password == password)
                {
                    var mainWindow = new MainWindow(user);
                    mainWindow.Show();
                    this.Close();
                }
                else
                {
                    ShowError("Неверный пароль");
                }
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка: {ex.Message}");
            }
        }

        private void OnGuestClick(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
        {
            var guestUser = new User
            {
                Id = -1,
                FullName = "Гость",
                Login = "guest",
                Password = "",
                Role = "guest"
            };
            
            var mainWindow = new MainWindow(guestUser);
            mainWindow.Show();
            this.Close();
        }

        private void ShowError(string message)
        {
            if (ErrorTextBlock != null)
            {
                ErrorTextBlock.Text = message;
                ErrorTextBlock.IsVisible = true;
            }
        }

        protected override void OnClosed(EventArgs e)
        {
            _dbContext?.Dispose();
            base.OnClosed(e);
        }
    }
}