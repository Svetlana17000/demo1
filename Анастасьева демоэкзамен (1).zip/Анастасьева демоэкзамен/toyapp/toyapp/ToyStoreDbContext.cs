using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ToyStore
{

    [Table("users")]
    public class User
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("full_name")]
        [Required]
        [StringLength(200)]
        public string FullName { get; set; } = "";

        [Column("login")]
        [Required]
        [StringLength(100)]
        public string Login { get; set; } = "";

        [Column("password")]
        [Required]
        [StringLength(100)]
        public string Password { get; set; } = "";

        [Column("role")]
        [StringLength(50)]
        public string Role { get; set; } = "client";

        [Column("created_at")]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public string RoleDisplay
        {
            get
            {
                return Role switch
                {
                    "admin" => "Администратор",
                    "manager" => "Менеджер",
                    "client" => "Клиент",
                    "guest" => "Гость",
                    _ => Role
                };
            }
        }
    }

   [Table("products")]
public class Product
{
    [Key]
    [Column("id")]
    public int Id { get; set; }

    [Column("article")]
    [Required]
    [StringLength(50)]
    public string Article { get; set; } = "";

    [Column("name")]
    [Required]
    [StringLength(200)]
    public string Name { get; set; } = "";

    [Column("unit")]
    [StringLength(20)]
    public string Unit { get; set; } = "шт.";

    [Column("price")]
    public decimal Price { get; set; }

    [Column("supplier")]
    [StringLength(200)]
    public string? Supplier { get; set; }

    [Column("manufacturer")]
    [StringLength(200)]
    public string? Manufacturer { get; set; }

    [Column("category")]
    [StringLength(100)]
    public string? Category { get; set; }

    [Column("discount")]
    public int Discount { get; set; } = 0;

    [Column("stock_quantity")]
    public int StockQuantity { get; set; } = 0;

    [Column("description")]
    public string? Description { get; set; }

    [Column("photo_url")]
    [StringLength(500)]
    public string? PhotoUrl { get; set; }

    // ДОБАВЛЕННЫЕ СВОЙСТВА ДЛЯ ОТОБРАЖЕНИЯ ЦЕНЫ:
    public string PriceWithDiscountDisplay => $"{PriceWithDiscount:F2} ₽";
    public string PriceDisplay => $"{Price:F2} ₽";

    public decimal PriceWithDiscount => Price * (100 - Discount) / 100;
    public bool IsHighDiscount => Discount > 15;
    public string StockStatus => StockQuantity > 0 ? $"В наличии: {StockQuantity} {Unit}" : "Нет в наличии";
}

    [Table("pickup_points")]
    public class PickupPoint
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("address")]
        [Required]
        [StringLength(500)]
        public string Address { get; set; } = "";
        
        public string AddressDisplay => $"Пункт выдачи: {Address}";
    }

    [Table("orders")]
    public class Order
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("order_number")]
        [Required]
        [StringLength(50)]
        public string OrderNumber { get; set; } = "";

        [Column("order_date")]
        public DateTime OrderDate { get; set; } = DateTime.UtcNow;

        [Column("delivery_date")]
        public DateTime DeliveryDate { get; set; }

        [Column("pickup_point_id")]
        public int? PickupPointId { get; set; }

        [Column("client_full_name")]
        [StringLength(200)]
        public string? ClientFullName { get; set; }

        [Column("pickup_code")]
        [StringLength(50)]
        public string? PickupCode { get; set; }

        [Column("status")]
        [StringLength(50)]
        public string Status { get; set; } = "Новый";

        [ForeignKey("PickupPointId")]
        public virtual PickupPoint? PickupPoint { get; set; }

        public virtual ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
        
        public string OrderNumberDisplay => $"Номер: {OrderNumber}";
        public string ClientFullNameDisplay => $"Клиент: {ClientFullName ?? "Не указан"}";
        public string StatusDisplay => $"Статус: {Status}";
        public string OrderDateDisplay => OrderDate.ToString("dd.MM.yyyy");
        public string DeliveryDateDisplay => DeliveryDate.ToString("dd.MM.yyyy");
        public string FormattedOrderDate => $"Дата заказа: {OrderDateDisplay}";
        public string FormattedDeliveryDate => $"Дата доставки: {DeliveryDateDisplay}";
        public string PickupPointAddressDisplay => PickupPoint?.AddressDisplay ?? "Пункт выдачи: Не указан";
        
        public decimal TotalSum
        {
            get
            {
                decimal sum = 0;
                foreach (var item in OrderItems)
                {
                    if (item.Product != null)
                    {
                        sum += item.Product.PriceWithDiscount * item.Quantity;
                    }
                }
                return sum;
            }
        }
        
        public string TotalSumDisplay => $"{TotalSum:F2} руб.";
    }

    [Table("order_items")]
    public class OrderItem
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("order_id")]
        public int OrderId { get; set; }

        [Column("product_article")]
        [StringLength(50)]
        public string? ProductArticle { get; set; }

        [Column("quantity")]
        public int Quantity { get; set; } = 1;

        [ForeignKey("OrderId")]
        public virtual Order? Order { get; set; }

        [ForeignKey("ProductArticle")]
        public virtual Product? Product { get; set; }
        
        public decimal ItemSum => Product != null ? Product.PriceWithDiscount * Quantity : 0;
        public string ItemSumDisplay => $"{ItemSum:F2} руб.";
    }

    public class ToyStoreDbContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }
        public DbSet<PickupPoint> PickupPoints { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);
            
            options.UseNpgsql("Host=localhost;Port=5432;Database=postgres;Username=postgres;Password=12345;SearchPath=toystore")
                .UseSnakeCaseNamingConvention();
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("users");
                entity.HasKey(u => u.Id);
                entity.Property(u => u.FullName).HasColumnName("full_name").IsRequired().HasMaxLength(200);
                entity.Property(u => u.Login).HasColumnName("login").IsRequired().HasMaxLength(100);
                entity.HasIndex(u => u.Login).IsUnique();
                entity.Property(u => u.Password).HasColumnName("password").IsRequired().HasMaxLength(100);
                entity.Property(u => u.Role).HasColumnName("role").HasMaxLength(50).HasDefaultValue("client");
                entity.Property(u => u.CreatedAt).HasColumnName("created_at").HasDefaultValueSql("CURRENT_TIMESTAMP");
            });

            modelBuilder.Entity<Product>(entity =>
            {
                entity.ToTable("products");
                entity.HasKey(p => p.Id);
                entity.Property(p => p.Article).HasColumnName("article").IsRequired().HasMaxLength(50);
                entity.HasIndex(p => p.Article).IsUnique();
                entity.Property(p => p.Name).HasColumnName("name").IsRequired().HasMaxLength(200);
                entity.Property(p => p.Unit).HasColumnName("unit").HasMaxLength(20).HasDefaultValue("шт.");
                entity.Property(p => p.Price).HasColumnName("price").HasColumnType("decimal(18,2)");
                entity.Property(p => p.Supplier).HasColumnName("supplier").HasMaxLength(200);
                entity.Property(p => p.Manufacturer).HasColumnName("manufacturer").HasMaxLength(200);
                entity.Property(p => p.Category).HasColumnName("category").HasMaxLength(100);
                entity.Property(p => p.Discount).HasColumnName("discount").HasDefaultValue(0);
                entity.Property(p => p.StockQuantity).HasColumnName("stock_quantity").HasDefaultValue(0);
                entity.Property(p => p.Description).HasColumnName("description");
                entity.Property(p => p.PhotoUrl).HasColumnName("photo_url").HasMaxLength(500);
            });

            modelBuilder.Entity<PickupPoint>(entity =>
            {
                entity.ToTable("pickup_points");
                entity.HasKey(pp => pp.Id);
                entity.Property(pp => pp.Address).HasColumnName("address").IsRequired().HasMaxLength(500);
            });

            modelBuilder.Entity<Order>(entity =>
            {
                entity.ToTable("orders");
                entity.HasKey(o => o.Id);
                entity.Property(o => o.OrderNumber).HasColumnName("order_number").IsRequired().HasMaxLength(50);
                entity.HasIndex(o => o.OrderNumber).IsUnique();
                entity.Property(o => o.OrderDate).HasColumnName("order_date");
                entity.Property(o => o.DeliveryDate).HasColumnName("delivery_date");
                entity.Property(o => o.PickupPointId).HasColumnName("pickup_point_id");
                entity.Property(o => o.ClientFullName).HasColumnName("client_full_name").HasMaxLength(200);
                entity.Property(o => o.PickupCode).HasColumnName("pickup_code").HasMaxLength(50);
                entity.Property(o => o.Status).HasColumnName("status").HasMaxLength(50).HasDefaultValue("Новый");
                
                entity.HasOne(o => o.PickupPoint)
                      .WithMany()
                      .HasForeignKey(o => o.PickupPointId)
                      .OnDelete(DeleteBehavior.SetNull);
            });

            modelBuilder.Entity<OrderItem>(entity =>
            {
                entity.ToTable("order_items");
                entity.HasKey(oi => oi.Id);
                entity.Property(oi => oi.OrderId).HasColumnName("order_id");
                entity.Property(oi => oi.ProductArticle).HasColumnName("product_article").HasMaxLength(50);
                entity.Property(oi => oi.Quantity).HasColumnName("quantity").HasDefaultValue(1);
                
                entity.HasOne(oi => oi.Order)
                      .WithMany(o => o.OrderItems)
                      .HasForeignKey(oi => oi.OrderId)
                      .OnDelete(DeleteBehavior.Cascade);
                
                entity.HasOne(oi => oi.Product)
                      .WithMany()
                      .HasForeignKey(oi => oi.ProductArticle)
                      .HasPrincipalKey(p => p.Article)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            SeedData(modelBuilder);
        }

        private void SeedData(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PickupPoint>().HasData(
                new PickupPoint { Id = 1, Address = "420151, г. Лесной, ул. Вишневая, 32" },
                new PickupPoint { Id = 2, Address = "125061, г. Лесной, ул. Подгорная, 8" },
                new PickupPoint { Id = 3, Address = "630370, г. Лесной, ул. Шоссейная, 24" },
                new PickupPoint { Id = 4, Address = "400562, г. Лесной, ул. Зеленая, 32" },
                new PickupPoint { Id = 5, Address = "614510, г. Лесной, ул. Маяковского, 47" },
                new PickupPoint { Id = 6, Address = "410542, г. Лесной, ул. Светлая, 46" },
                new PickupPoint { Id = 7, Address = "620839, г. Лесной, ул. Цветочная, 8" },
                new PickupPoint { Id = 8, Address = "443890, г. Лесной, ул. Коммунистическая, 1" },
                new PickupPoint { Id = 9, Address = "603379, г. Лесной, ул. Спортивная, 46" },
                new PickupPoint { Id = 10, Address = "603721, г. Лесной, ул. Гоголя, 41" },
                new PickupPoint { Id = 11, Address = "410172, г. Лесной, ул. Северная, 13" },
                new PickupPoint { Id = 12, Address = "614611, г. Лесной, ул. Молодежная, 50" },
                new PickupPoint { Id = 13, Address = "454311, г.Лесной, ул. Новая, 19" },
                new PickupPoint { Id = 14, Address = "660007, г.Лесной, ул. Октябрьская, 19" },
                new PickupPoint { Id = 15, Address = "603036, г. Лесной, ул. Садовая, 4" },
                new PickupPoint { Id = 16, Address = "394060, г.Лесной, ул. Фрунзе, 43" },
                new PickupPoint { Id = 17, Address = "410661, г. Лесной, ул. Школьная, 50" },
                new PickupPoint { Id = 18, Address = "625590, г. Лесной, ул. Коммунистическая, 20" },
                new PickupPoint { Id = 19, Address = "625683, г. Лесной, ул. 8 Марта" },
                new PickupPoint { Id = 20, Address = "450983, г.Лесной, ул. Комсомольская, 26" },
                new PickupPoint { Id = 21, Address = "394782, г. Лесной, ул. Чехова, 3" },
                new PickupPoint { Id = 22, Address = "603002, г. Лесной, ул. Дзержинского, 28" },
                new PickupPoint { Id = 23, Address = "450558, г. Лесной, ул. Набережная, 30" },
                new PickupPoint { Id = 24, Address = "344288, г. Лесной, ул. Чехова, 1" },
                new PickupPoint { Id = 25, Address = "614164, г.Лесной, ул. Степная, 30" },
                new PickupPoint { Id = 26, Address = "394242, г. Лесной, ул. Коммунистическая, 43" },
                new PickupPoint { Id = 27, Address = "660540, г. Лесной, ул. Солнечная, 25" },
                new PickupPoint { Id = 28, Address = "125837, г. Лесной, ул. Шоссейная, 40" },
                new PickupPoint { Id = 29, Address = "125703, г. Лесной, ул. Партизанская, 49" },
                new PickupPoint { Id = 30, Address = "625283, г. Лесной, ул. Победы, 46" },
                new PickupPoint { Id = 31, Address = "614753, г. Лесной, ул. Полевая, 35" },
                new PickupPoint { Id = 32, Address = "426030, г. Лесной, ул. Маяковского, 44" },
                new PickupPoint { Id = 33, Address = "450375, г. Лесной ул. Клубная, 44" },
                new PickupPoint { Id = 34, Address = "625560, г. Лесной, ул. Некрасова, 12" },
                new PickupPoint { Id = 35, Address = "630201, г. Лесной, ул. Комсомольская, 17" },
                new PickupPoint { Id = 36, Address = "190949, г. Лесной, ул. Мичурина, 26" }
            );

            modelBuilder.Entity<Product>().HasData(
                new Product { Id = 1, Article = "PMEZMH", Name = "Детский игровой набор машинок Щенячий патруль / Dogs mini . 9 героев + 9 инерфионных машинок", Unit = "шт.", Price = 1414, Supplier = "Pikeshop", Manufacturer = "ABSпластик", Category = "Игровой набор", Discount = 22, StockQuantity = 50, Description = "Детский набор машинок с героями мультсериала «Щенячий патруль» подойдет как для мальчиков, так и для девочек. В детский набор входит 9 фигурок щенков спасателей.", PhotoUrl = "1.jpg" },
                new Product { Id = 2, Article = "BPV4MM", Name = "Конструктор Гарри Поттер Сова Букля 630 деталей совместим с lego harry potter, лего совместимый)", Unit = "шт.", Price = 771, Supplier = "Playbig", Manufacturer = "ABSпластик", Category = "Конструктор", Discount = 15, StockQuantity = 26, Description = "Коллекционная модель Букля состоит из множества потрясающих элементов, а также специального механизма внутри. С его помощью можно плавно поднимать-опускать крылья птицы.", PhotoUrl = "2.jpg" },
                new Product { Id = 3, Article = "JVL42J", Name = "Музыкальные инструменты для детей, ксилофон, барабаны, развивающие игрушки, игрушки для детей", Unit = "шт.", Price = 2750, Supplier = "Playbig", Manufacturer = "BambiniFelici", Category = "Детский музыкальный инструмент", Discount = 15, StockQuantity = 0, Description = "Откройте мир музыки для вашего ребенка с этой уникальной игрушкой! Это многофункциональное музыкальное чудо объединяет в себе всё, что нужно для творческого развития.", PhotoUrl = "3.jpg" },
                new Product { Id = 4, Article = "F895RB", Name = "Машинка игрушка диско шар светящаяся музыкальная", Unit = "шт.", Price = 368, Supplier = "Knauf", Manufacturer = "ABSпластик", Category = "Машинка", Discount = 6, StockQuantity = 7, Description = "Светящаяся музыкальная машина с диско шаром переливается разными цветами, играет ритмичные мелодии, объезжает препятствия и крутится, поэтому с ней точно не будет скучно.", PhotoUrl = "4.jpg" },
                new Product { Id = 5, Article = "3XBOTN", Name = "Игровой набор Hot Wheels Action Loop Cyclone Challenge Track, с машинкой и удобным хранением, HTK16", Unit = "шт.", Price = 3426, Supplier = "Knauf", Manufacturer = "BambiniFelici", Category = "Игровой набор", Discount = 10, StockQuantity = 21, Description = "Игровой набор Hot Wheels Action Loop Cyclone Challenge Track - это уникальная игра, которая позволит вам испытать себя и своих друзей в скорости и ловкости. Этот набор состоит из металлической дорожки с циклоном, которая создает потрясающий эффект и добавляет дополнительную сложность в игру.", PhotoUrl = "5.jpg" },
                new Product { Id = 6, Article = "3L7RCZ", Name = "Игровой набор с деревянными машинками Стройплощадка Кран-Паркс, Junion", Unit = "шт.", Price = 7400, Supplier = "Knauf", Manufacturer = "Junion", Category = "Игровой набор", Discount = 15, StockQuantity = 0, Description = "Игровой набор «Стройплощадка Кран-Паркс Junion» — это большая игрушечная парковка с деревянными машинками и настоящим подъёмным краном, придуманная в Яндексе настоящими родителями.", PhotoUrl = "6.jpg" },
                new Product { Id = 7, Article = "S72AM3", Name = "Синтезатор детский с микрофоном 61 клавиша", Unit = "шт.", Price = 1749, Supplier = "CHILITOY", Manufacturer = "Junion", Category = "Детский музыкальный инструмент", Discount = 10, StockQuantity = 35, Description = "Откройте для ребенка дверь в мир музыки с детским синтезатором! Этот компактный инструмент с микрофоном станет верным другом для юных музыкантов, помогая им развивать творческий потенциал и получать удовольствие от игры.", PhotoUrl = "7.jpg" },
                new Product { Id = 8, Article = "2G3280", Name = "Деревянный игровой набор JUNION Стройплощадка \"Кран-Паркс\" с подъёмным, строительным краном и машинками, 18 предметов, подвижные элементы", Unit = "шт.", Price = 1624, Supplier = "Vinylon", Manufacturer = "Junion", Category = "Игровой набор", Discount = 9, StockQuantity = 20, Description = "Игровой набор «Стройплощадка Кран-Паркс Junion» — это большая игрушечная парковка с деревянными машинками и настоящим подъёмным краном, придуманная в Яндексе настоящими родителями.", PhotoUrl = "8.jpg" },
                new Product { Id = 9, Article = "MIO8YV", Name = "Музыкальная игрушка интерактивная Пульт, детский прорезыватель для малышей", Unit = "шт.", Price = 305, Supplier = "Vinylon", Manufacturer = "BambiniFelici", Category = "Детский музыкальный инструмент", Discount = 9, StockQuantity = 31, Description = "Музыкальная игрушка интерактивная Пульт, детский прорезыватель для малышей", PhotoUrl = "9.jpg" },
                new Product { Id = 10, Article = "UER2QD", Name = "Большой набор опытов и экспериментов для детей 14 в 1", Unit = "шт.", Price = 2506, Supplier = "Vinylon", Manufacturer = "BambiniFelici", Category = "Игровой набор", Discount = 8, StockQuantity = 27, Description = "Большой набор опытов и экспериментов для детей 14 в 1", PhotoUrl = "10.jpg" }
            );

            modelBuilder.Entity<User>().HasData(
                new User { Id = 1, FullName = "Ворсин Петр Евгеньевич", Login = "94d5ous@gmail.com", Password = "uzWC67", Role = "admin", CreatedAt = DateTime.UtcNow },
                new User { Id = 2, FullName = "Старикова Елена Павловна", Login = "uth4iz@mail.com", Password = "2L6KZG", Role = "admin", CreatedAt = DateTime.UtcNow },
                new User { Id = 3, FullName = "Одинцов Серафим Артёмович", Login = "yzls62@outlook.com", Password = "JlFRCZ", Role = "admin", CreatedAt = DateTime.UtcNow },
                new User { Id = 4, FullName = "Михайлюк Анна Вячеславовна", Login = "1diph5e@tutanota.com", Password = "8ntwUp", Role = "manager", CreatedAt = DateTime.UtcNow },
                new User { Id = 5, FullName = "Ситдикова Елена Анатольевна", Login = "tjde7c@yahoo.com", Password = "YOyhfR", Role = "manager", CreatedAt = DateTime.UtcNow },
                new User { Id = 6, FullName = "Никифорова Весения Николаевна", Login = "wpmrc3do@tutanota.com", Password = "RSbvHv", Role = "manager", CreatedAt = DateTime.UtcNow },
                new User { Id = 7, FullName = "Степанов Михаил Артёмович", Login = "5d4zbu@tutanota.com", Password = "rwVDh9", Role = "client", CreatedAt = DateTime.UtcNow },
                new User { Id = 8, FullName = "Ворсин Петр Евгеньевич", Login = "ptec8ym@yahoo.com", Password = "LdNyos", Role = "client", CreatedAt = DateTime.UtcNow },
                new User { Id = 9, FullName = "Старикова Елена Павловна", Login = "1qz4kw@mail.com", Password = "gynQMT", Role = "client", CreatedAt = DateTime.UtcNow },
                new User { Id = 10, FullName = "Сазонов Руслан Германович", Login = "4np6se@mail.com", Password = "AtnDjr", Role = "client", CreatedAt = DateTime.UtcNow }
            );

            modelBuilder.Entity<Order>().HasData(
                new Order { Id = 1, OrderNumber = "1", OrderDate = new DateTime(2025, 2, 27), DeliveryDate = new DateTime(2025, 4, 20), PickupPointId = 1, ClientFullName = "Степанов Михаил Артёмович", PickupCode = "901", Status = "Завершен" },
                new Order { Id = 2, OrderNumber = "2", OrderDate = new DateTime(2024, 9, 28), DeliveryDate = new DateTime(2025, 4, 21), PickupPointId = 11, ClientFullName = "Ворсин Петр Евгеньевич", PickupCode = "902", Status = "Завершен" },
                new Order { Id = 3, OrderNumber = "3", OrderDate = new DateTime(2025, 3, 21), DeliveryDate = new DateTime(2025, 4, 22), PickupPointId = 2, ClientFullName = "Старикова Елена Павловна", PickupCode = "903", Status = "Завершен" },
                new Order { Id = 4, OrderNumber = "4", OrderDate = new DateTime(2025, 2, 20), DeliveryDate = new DateTime(2025, 4, 23), PickupPointId = 11, ClientFullName = "Сазонов Руслан Германович", PickupCode = "904", Status = "Завершен" },
                new Order { Id = 5, OrderNumber = "5", OrderDate = new DateTime(2025, 3, 17), DeliveryDate = new DateTime(2025, 4, 24), PickupPointId = 2, ClientFullName = "Степанов Михаил Артёмович", PickupCode = "905", Status = "Завершен" },
                new Order { Id = 6, OrderNumber = "6", OrderDate = new DateTime(2025, 3, 1), DeliveryDate = new DateTime(2025, 4, 25), PickupPointId = 15, ClientFullName = "Ворсин Петр Евгеньевич", PickupCode = "906", Status = "Завершен" },
                new Order { Id = 7, OrderNumber = "7", OrderDate = new DateTime(2025, 2, 28), DeliveryDate = new DateTime(2025, 4, 26), PickupPointId = 3, ClientFullName = "Старикова Елена Павловна", PickupCode = "907", Status = "Завершен" },
                new Order { Id = 8, OrderNumber = "8", OrderDate = new DateTime(2025, 3, 31), DeliveryDate = new DateTime(2025, 4, 27), PickupPointId = 19, ClientFullName = "Сазонов Руслан Германович", PickupCode = "908", Status = "Новый" },
                new Order { Id = 9, OrderNumber = "9", OrderDate = new DateTime(2025, 4, 2), DeliveryDate = new DateTime(2025, 4, 28), PickupPointId = 5, ClientFullName = "Старикова Елена Павловна", PickupCode = "909", Status = "Новый" },
                new Order { Id = 10, OrderNumber = "10", OrderDate = new DateTime(2025, 4, 3), DeliveryDate = new DateTime(2025, 4, 29), PickupPointId = 19, ClientFullName = "Сазонов Руслан Германович", PickupCode = "910", Status = "Новый" }
            );

            modelBuilder.Entity<OrderItem>().HasData(
                new OrderItem { Id = 1, OrderId = 1, ProductArticle = "PMEZMH", Quantity = 2 },
                new OrderItem { Id = 2, OrderId = 1, ProductArticle = "BPV4MM", Quantity = 2 },
                new OrderItem { Id = 3, OrderId = 2, ProductArticle = "JVL42J", Quantity = 1 },
                new OrderItem { Id = 4, OrderId = 2, ProductArticle = "F895RB", Quantity = 1 },
                new OrderItem { Id = 5, OrderId = 3, ProductArticle = "3XBOTN", Quantity = 10 },
                new OrderItem { Id = 6, OrderId = 3, ProductArticle = "3L7RCZ", Quantity = 10 },
                new OrderItem { Id = 7, OrderId = 4, ProductArticle = "S72AM3", Quantity = 5 },
                new OrderItem { Id = 8, OrderId = 4, ProductArticle = "2G3280", Quantity = 4 },
                new OrderItem { Id = 9, OrderId = 5, ProductArticle = "MIO8YV", Quantity = 2 },
                new OrderItem { Id = 10, OrderId = 5, ProductArticle = "UER2QD", Quantity = 2 },
                new OrderItem { Id = 11, OrderId = 6, ProductArticle = "PMEZMH", Quantity = 2 },
                new OrderItem { Id = 12, OrderId = 6, ProductArticle = "BPV4MM", Quantity = 2 },
                new OrderItem { Id = 13, OrderId = 7, ProductArticle = "JVL42J", Quantity = 1 },
                new OrderItem { Id = 14, OrderId = 7, ProductArticle = "F895RB", Quantity = 1 },
                new OrderItem { Id = 15, OrderId = 8, ProductArticle = "3XBOTN", Quantity = 10 },
                new OrderItem { Id = 16, OrderId = 8, ProductArticle = "3L7RCZ", Quantity = 10 },
                new OrderItem { Id = 17, OrderId = 9, ProductArticle = "S72AM3", Quantity = 5 },
                new OrderItem { Id = 18, OrderId = 9, ProductArticle = "2G3280", Quantity = 4 },
                new OrderItem { Id = 19, OrderId = 10, ProductArticle = "MIO8YV", Quantity = 2 },
                new OrderItem { Id = 20, OrderId = 10, ProductArticle = "UER2QD", Quantity = 2 }
            );
        }
    }
}