using Avalonia.Controls;
using Avalonia.Interactivity;
using System;
using System.Linq;

namespace ToyStore
{
    public partial class ProductEditWindow : Window
    {
        private readonly ToyStoreDbContext _dbContext;
        private readonly Product? _product;
        private readonly bool _isEdit;
        private bool _isSaved = false;

        public ProductEditWindow(Product? product = null)
        {
            InitializeComponent();
            _dbContext = new ToyStoreDbContext();
            _product = product;
            _isEdit = product != null;
            
            this.Title = _isEdit ? "Редактирование товара" : "Добавление товара";
            
            if (_isEdit && _product != null)
            {
                LoadProductData();
            }
            
            SaveButton.Click += OnSaveClick;
            CancelButton.Click += (s, e) => Close();
        }

        public bool IsSaved => _isSaved;

        private void LoadProductData()
        {
            if (_product == null) return;
            
            ArticleTextBox.Text = _product.Article;
            NameTextBox.Text = _product.Name;
            PriceTextBox.Text = _product.Price.ToString();
            DiscountTextBox.Text = _product.Discount.ToString();
            
            // Установка категории
            if (!string.IsNullOrEmpty(_product.Category))
            {
                for (int i = 0; i < CategoryComboBox.Items.Count; i++)
                {
                    var item = CategoryComboBox.Items[i] as ComboBoxItem;
                    if (item != null && item.Content?.ToString() == _product.Category)
                    {
                        CategoryComboBox.SelectedIndex = i;
                        break;
                    }
                }
            }
            
            ManufacturerTextBox.Text = _product.Manufacturer;
            SupplierTextBox.Text = _product.Supplier;
            StockTextBox.Text = _product.StockQuantity.ToString();
            UnitTextBox.Text = _product.Unit;
            DescriptionTextBox.Text = _product.Description;
            PhotoUrlTextBox.Text = _product.PhotoUrl;
        }

        private async void OnSaveClick(object? sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(ArticleTextBox.Text))
                {
                    ShowError("Введите артикул");
                    return;
                }
                if (string.IsNullOrWhiteSpace(NameTextBox.Text))
                {
                    ShowError("Введите название");
                    return;
                }
                if (!decimal.TryParse(PriceTextBox.Text, out decimal price))
                {
                    ShowError("Введите корректную цену");
                    return;
                }
                
                int discount = 0;
                if (!string.IsNullOrWhiteSpace(DiscountTextBox.Text))
                {
                    if (!int.TryParse(DiscountTextBox.Text, out discount) || discount < 0 || discount > 100)
                    {
                        ShowError("Скидка должна быть от 0 до 100");
                        return;
                    }
                }
                
                int stock = 0;
                if (!string.IsNullOrWhiteSpace(StockTextBox.Text))
                {
                    if (!int.TryParse(StockTextBox.Text, out stock) || stock < 0)
                    {
                        ShowError("Введите корректное количество");
                        return;
                    }
                }
                
                string category = (CategoryComboBox.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "";
                
                if (_isEdit && _product != null)
                {
                    var existingProduct = await _dbContext.Products.FindAsync(_product.Id);
                    if (existingProduct != null)
                    {
                        existingProduct.Article = ArticleTextBox.Text;
                        existingProduct.Name = NameTextBox.Text;
                        existingProduct.Price = price;
                        existingProduct.Discount = discount;
                        existingProduct.Category = category;
                        existingProduct.Manufacturer = ManufacturerTextBox.Text;
                        existingProduct.Supplier = SupplierTextBox.Text;
                        existingProduct.StockQuantity = stock;
                        existingProduct.Unit = UnitTextBox.Text;
                        existingProduct.Description = DescriptionTextBox.Text;
                        existingProduct.PhotoUrl = PhotoUrlTextBox.Text;
                        
                        _dbContext.Products.Update(existingProduct);
                    }
                }
                else
                {
                    var newProduct = new Product
                    {
                        Article = ArticleTextBox.Text,
                        Name = NameTextBox.Text,
                        Price = price,
                        Discount = discount,
                        Category = category,
                        Manufacturer = ManufacturerTextBox.Text,
                        Supplier = SupplierTextBox.Text,
                        StockQuantity = stock,
                        Unit = UnitTextBox.Text,
                        Description = DescriptionTextBox.Text,
                        PhotoUrl = PhotoUrlTextBox.Text
                    };
                    
                    await _dbContext.Products.AddAsync(newProduct);
                }
                
                await _dbContext.SaveChangesAsync();
                _isSaved = true;
                Close();
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка: {ex.Message}");
            }
        }

        private void ShowError(string message)
        {
            ErrorTextBlock.Text = message;
            ErrorTextBlock.IsVisible = true;
        }
    }
}