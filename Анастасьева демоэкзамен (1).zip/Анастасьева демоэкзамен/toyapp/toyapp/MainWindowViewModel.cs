using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using Microsoft.EntityFrameworkCore;

namespace ToyStore.ViewModels
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        private readonly ToyStoreDbContext _dbContext;
        private readonly User _currentUser;
        
        public event PropertyChangedEventHandler? PropertyChanged;
        
        protected void OnPropertyChanged([CallerMemberName] string? name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        public User CurrentUser => _currentUser;
        public bool IsManagerOrAdmin => _currentUser.Role == "manager" || _currentUser.Role == "admin";
        public bool IsAdmin => _currentUser.Role == "admin";

        private ObservableCollection<Product> _products = new();
        public ObservableCollection<Product> Products
        {
            get => _products;
            set { _products = value; OnPropertyChanged(); }
        }

        private ObservableCollection<Product> _filteredProducts = new();
        public ObservableCollection<Product> FilteredProducts
        {
            get => _filteredProducts;
            set { _filteredProducts = value; OnPropertyChanged(); }
        }

        private ObservableCollection<Order> _orders = new();
        public ObservableCollection<Order> Orders
        {
            get => _orders;
            set { _orders = value; OnPropertyChanged(); }
        }

        private ObservableCollection<Order> _filteredOrders = new();
        public ObservableCollection<Order> FilteredOrders
        {
            get => _filteredOrders;
            set { _filteredOrders = value; OnPropertyChanged(); }
        }

        private string _searchText = "";
        public string SearchText
        {
            get => _searchText;
            set { _searchText = value; OnPropertyChanged(); ApplyFilters(); }
        }

        private string _selectedCategory = "Все";
        public string SelectedCategory
        {
            get => _selectedCategory;
            set { _selectedCategory = value; OnPropertyChanged(); ApplyFilters(); }
        }

        private string _selectedManufacturer = "Все";
        public string SelectedManufacturer
        {
            get => _selectedManufacturer;
            set { _selectedManufacturer = value; OnPropertyChanged(); ApplyFilters(); }
        }

        private string _selectedSort = "Название (А-Я)";
        public string SelectedSort
        {
            get => _selectedSort;
            set { _selectedSort = value; OnPropertyChanged(); ApplyFilters(); }
        }

        public ObservableCollection<string> Categories { get; set; } = new();
        public ObservableCollection<string> Manufacturers { get; set; } = new();
        public ObservableCollection<string> SortOptions { get; set; } = new()
        {
            "Название (А-Я)", "Название (Я-А)", "Цена (возрастание)", "Цена (убывание)", "Скидка (возрастание)", "Скидка (убывание)"
        };

        private string _orderSearchText = "";
        public string OrderSearchText
        {
            get => _orderSearchText;
            set { _orderSearchText = value; OnPropertyChanged(); ApplyOrderFilters(); }
        }

        private string _selectedOrderStatus = "Все";
        public string SelectedOrderStatus
        {
            get => _selectedOrderStatus;
            set { _selectedOrderStatus = value; OnPropertyChanged(); ApplyOrderFilters(); }
        }

        public ObservableCollection<string> OrderStatuses { get; set; } = new()
        {
            "Все", "Новый", "Завершен", "Отменен"
        };

        private Order? _selectedOrder;
        public Order? SelectedOrder
        {
            get => _selectedOrder;
            set
            {
                _selectedOrder = value;
                OnPropertyChanged();
                LoadOrderItems();
                OnPropertyChanged(nameof(FormattedOrderDate));
                OnPropertyChanged(nameof(FormattedDeliveryDate));
                OnPropertyChanged(nameof(FormattedOrderTotal));
            }
        }

        private ObservableCollection<OrderItemDetail> _orderItems = new();
        public ObservableCollection<OrderItemDetail> OrderItems
        {
            get => _orderItems;
            set { _orderItems = value; OnPropertyChanged(); OnPropertyChanged(nameof(OrderTotal)); OnPropertyChanged(nameof(FormattedOrderTotal)); }
        }

        public decimal OrderTotal => OrderItems.Sum(i => i.Total);
        
        public string FormattedOrderDate => SelectedOrder?.OrderDate.ToString("dd.MM.yyyy") ?? "";
        public string FormattedDeliveryDate => SelectedOrder?.DeliveryDate.ToString("dd.MM.yyyy") ?? "";
        public string FormattedOrderTotal => OrderTotal.ToString("F2") + " ₽";

        public MainWindowViewModel(User user)
        {
            _currentUser = user;
            _dbContext = new ToyStoreDbContext();
            
            LoadProducts();
            if (IsManagerOrAdmin)
            {
                LoadOrders();
            }
        }

        public void LoadProducts()
        {
            _dbContext.ChangeTracker.Clear();
            
            var allProducts = _dbContext.Products.ToList();
            Products.Clear();
            foreach (var p in allProducts)
            {
                Products.Add(p);
            }
            
            Categories.Clear();
            Manufacturers.Clear();
            Categories.Add("Все");
            Manufacturers.Add("Все");
            
            foreach (var category in Products.Select(p => p.Category).Where(c => !string.IsNullOrEmpty(c)).Distinct())
            {
                Categories.Add(category!);
            }
            
            foreach (var manufacturer in Products.Select(p => p.Manufacturer).Where(m => !string.IsNullOrEmpty(m)).Distinct())
            {
                Manufacturers.Add(manufacturer!);
            }
            
            ApplyFilters();
        }

        public void ApplyFilters()
        {
            var query = Products.AsEnumerable();
            
            if (!string.IsNullOrWhiteSpace(SearchText))
            {
                query = query.Where(p =>
                    p.Name.Contains(SearchText, StringComparison.OrdinalIgnoreCase) ||
                    p.Article.Contains(SearchText, StringComparison.OrdinalIgnoreCase) ||
                    (p.Description != null && p.Description.Contains(SearchText, StringComparison.OrdinalIgnoreCase)));
            }
            
            if (SelectedCategory != "Все")
            {
                query = query.Where(p => p.Category == SelectedCategory);
            }
            
            if (SelectedManufacturer != "Все")
            {
                query = query.Where(p => p.Manufacturer == SelectedManufacturer);
            }
            
            query = SelectedSort switch
            {
                "Название (А-Я)" => query.OrderBy(p => p.Name),
                "Название (Я-А)" => query.OrderByDescending(p => p.Name),
                "Цена (возрастание)" => query.OrderBy(p => p.PriceWithDiscount),
                "Цена (убывание)" => query.OrderByDescending(p => p.PriceWithDiscount),
                "Скидка (возрастание)" => query.OrderBy(p => p.Discount),
                "Скидка (убывание)" => query.OrderByDescending(p => p.Discount),
                _ => query.OrderBy(p => p.Name)
            };
            
            FilteredProducts.Clear();
            foreach (var product in query)
            {
                FilteredProducts.Add(product);
            }
        }

        public void LoadOrders()
        {
            var orders = _dbContext.Orders
                .Include(o => o.PickupPoint)
                .OrderByDescending(o => o.OrderDate)
                .ToList();
            
            Orders.Clear();
            foreach (var order in orders)
            {
                Orders.Add(order);
            }
            
            ApplyOrderFilters();
        }

        private void ApplyOrderFilters()
        {
            var query = Orders.AsEnumerable();
            
            if (!string.IsNullOrWhiteSpace(OrderSearchText))
            {
                query = query.Where(o =>
                    o.OrderNumber.Contains(OrderSearchText, StringComparison.OrdinalIgnoreCase) ||
                    (o.ClientFullName != null && o.ClientFullName.Contains(OrderSearchText, StringComparison.OrdinalIgnoreCase)));
            }
            
            if (SelectedOrderStatus != "Все")
            {
                query = query.Where(o => o.Status == SelectedOrderStatus);
            }
            
            FilteredOrders.Clear();
            foreach (var order in query)
            {
                FilteredOrders.Add(order);
            }
        }

        private void LoadOrderItems()
        {
            if (SelectedOrder == null)
            {
                OrderItems.Clear();
                return;
            }
            
            var items = from oi in _dbContext.OrderItems
                        join p in _dbContext.Products on oi.ProductArticle equals p.Article
                        where oi.OrderId == SelectedOrder.Id
                        select new OrderItemDetail
                        {
                            ProductArticle = p.Article,
                            ProductName = p.Name,
                            Quantity = oi.Quantity,
                            Price = p.PriceWithDiscount,
                            Total = p.PriceWithDiscount * oi.Quantity
                        };
            
            OrderItems.Clear();
            foreach (var item in items)
            {
                OrderItems.Add(item);
            }
        }

        public void DeleteProduct(Product product)
        {
            try
            {
                if (product == null) return;
                
                var productToDelete = _dbContext.Products.FirstOrDefault(p => p.Id == product.Id);
                
                if (productToDelete != null)
                {
                    var orderItems = _dbContext.OrderItems.Where(oi => oi.ProductArticle == productToDelete.Article);
                    _dbContext.OrderItems.RemoveRange(orderItems);
                    _dbContext.Products.Remove(productToDelete);
                    _dbContext.SaveChanges();
                }
                LoadProducts();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка удаления: {ex.Message}");
            }
        }

        public void ResetFilters()
        {
            SearchText = "";
            SelectedCategory = "Все";
            SelectedManufacturer = "Все";
            SelectedSort = "Название (А-Я)";
        }

        public void DeleteOrder()
        {
            if (SelectedOrder != null)
            {
                try
                {
                    var itemsToDelete = _dbContext.OrderItems.Where(oi => oi.OrderId == SelectedOrder.Id);
                    _dbContext.OrderItems.RemoveRange(itemsToDelete);
                    _dbContext.SaveChanges();
                    
                    _dbContext.Orders.Remove(SelectedOrder);
                    _dbContext.SaveChanges();
                    LoadOrders();
                    SelectedOrder = null;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка удаления: {ex.Message}");
                }
            }
        }

        public class OrderItemDetail
        {
            public string ProductArticle { get; set; } = "";
            public string ProductName { get; set; } = "";
            public int Quantity { get; set; }
            public decimal Price { get; set; }
            public decimal Total { get; set; }
            public string FormattedTotal => Total.ToString("F2") + " ₽";
            public string QuantityText => $"{Quantity} шт.";
        }
    }
}