using Avalonia.Controls;
using Avalonia.Interactivity;
using System.Linq;

namespace ToyStore
{
    public partial class ProductSelectorWindow : Window
    {
        private readonly ToyStoreDbContext _dbContext;
        public Product? SelectedProduct { get; private set; }
        public int SelectedQuantity { get; private set; }

        public ProductSelectorWindow(ToyStoreDbContext dbContext)
        {
            InitializeComponent();
            _dbContext = dbContext;
            
            LoadProducts();
            SearchTextBox.TextChanged += (s, e) => LoadProducts();
            ConfirmButton.Click += OnConfirmClick;
            CancelButton.Click += (s, e) => Close();
        }

        private void LoadProducts()
        {
            var query = _dbContext.Products.AsQueryable();
            
            if (!string.IsNullOrWhiteSpace(SearchTextBox.Text))
            {
                query = query.Where(p => p.Name.Contains(SearchTextBox.Text) || p.Article.Contains(SearchTextBox.Text));
            }
            
            ProductsListBox.ItemsSource = query.ToList();
        }

        private void OnConfirmClick(object? sender, RoutedEventArgs e)
        {
            SelectedProduct = ProductsListBox.SelectedItem as Product;
            
            if (SelectedProduct == null)
            {
                return;
            }
            
            if (!int.TryParse(QuantityTextBox.Text, out int quantity) || quantity <= 0)
            {
                quantity = 1;
            }
            
            SelectedQuantity = quantity;
            Close();
        }
    }
}