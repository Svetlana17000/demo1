﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

#pragma warning disable CA1814 

namespace ToyStore.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "pickup_points",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    address = table.Column<string>(type: "character varying(500)", maxLength: 500, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_pickup_points", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "products",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    article = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    name = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: false),
                    unit = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false, defaultValue: "шт."),
                    price = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    supplier = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: true),
                    manufacturer = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: true),
                    category = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    discount = table.Column<int>(type: "integer", nullable: false, defaultValue: 0),
                    stock_quantity = table.Column<int>(type: "integer", nullable: false, defaultValue: 0),
                    description = table.Column<string>(type: "text", nullable: true),
                    photo_url = table.Column<string>(type: "character varying(500)", maxLength: 500, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_products", x => x.id);
                    table.UniqueConstraint("ak_products_article", x => x.article);
                });

            migrationBuilder.CreateTable(
                name: "users",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    full_name = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: false),
                    login = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    password = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    role = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false, defaultValue: "client"),
                    created_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: false, defaultValueSql: "CURRENT_TIMESTAMP")
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_users", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "orders",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    order_number = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    order_date = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    delivery_date = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    pickup_point_id = table.Column<int>(type: "integer", nullable: true),
                    client_full_name = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: true),
                    pickup_code = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    status = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false, defaultValue: "Новый")
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_orders", x => x.id);
                    table.ForeignKey(
                        name: "fk_orders_pickup_points_pickup_point_id",
                        column: x => x.pickup_point_id,
                        principalTable: "pickup_points",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "order_items",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    order_id = table.Column<int>(type: "integer", nullable: false),
                    product_article = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    quantity = table.Column<int>(type: "integer", nullable: false, defaultValue: 1)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_order_items", x => x.id);
                    table.ForeignKey(
                        name: "fk_order_items_orders_order_id",
                        column: x => x.order_id,
                        principalTable: "orders",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_order_items_products_product_article",
                        column: x => x.product_article,
                        principalTable: "products",
                        principalColumn: "article",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "pickup_points",
                columns: new[] { "id", "address" },
                values: new object[,]
                {
                    { 1, "420151, г. Лесной, ул. Вишневая, 32" },
                    { 2, "125061, г. Лесной, ул. Подгорная, 8" },
                    { 3, "630370, г. Лесной, ул. Шоссейная, 24" },
                    { 4, "400562, г. Лесной, ул. Зеленая, 32" },
                    { 5, "614510, г. Лесной, ул. Маяковского, 47" },
                    { 6, "410542, г. Лесной, ул. Светлая, 46" },
                    { 7, "620839, г. Лесной, ул. Цветочная, 8" },
                    { 8, "443890, г. Лесной, ул. Коммунистическая, 1" },
                    { 9, "603379, г. Лесной, ул. Спортивная, 46" },
                    { 10, "603721, г. Лесной, ул. Гоголя, 41" },
                    { 11, "410172, г. Лесной, ул. Северная, 13" },
                    { 12, "614611, г. Лесной, ул. Молодежная, 50" },
                    { 13, "454311, г.Лесной, ул. Новая, 19" },
                    { 14, "660007, г.Лесной, ул. Октябрьская, 19" },
                    { 15, "603036, г. Лесной, ул. Садовая, 4" },
                    { 16, "394060, г.Лесной, ул. Фрунзе, 43" },
                    { 17, "410661, г. Лесной, ул. Школьная, 50" },
                    { 18, "625590, г. Лесной, ул. Коммунистическая, 20" },
                    { 19, "625683, г. Лесной, ул. 8 Марта" },
                    { 20, "450983, г.Лесной, ул. Комсомольская, 26" },
                    { 21, "394782, г. Лесной, ул. Чехова, 3" },
                    { 22, "603002, г. Лесной, ул. Дзержинского, 28" },
                    { 23, "450558, г. Лесной, ул. Набережная, 30" },
                    { 24, "344288, г. Лесной, ул. Чехова, 1" },
                    { 25, "614164, г.Лесной, ул. Степная, 30" },
                    { 26, "394242, г. Лесной, ул. Коммунистическая, 43" },
                    { 27, "660540, г. Лесной, ул. Солнечная, 25" },
                    { 28, "125837, г. Лесной, ул. Шоссейная, 40" },
                    { 29, "125703, г. Лесной, ул. Партизанская, 49" },
                    { 30, "625283, г. Лесной, ул. Победы, 46" },
                    { 31, "614753, г. Лесной, ул. Полевая, 35" },
                    { 32, "426030, г. Лесной, ул. Маяковского, 44" },
                    { 33, "450375, г. Лесной ул. Клубная, 44" },
                    { 34, "625560, г. Лесной, ул. Некрасова, 12" },
                    { 35, "630201, г. Лесной, ул. Комсомольская, 17" },
                    { 36, "190949, г. Лесной, ул. Мичурина, 26" }
                });

            migrationBuilder.InsertData(
                table: "products",
                columns: new[] { "id", "article", "category", "description", "discount", "manufacturer", "name", "photo_url", "price", "stock_quantity", "supplier", "unit" },
                values: new object[,]
                {
                    { 1, "PMEZMH", "Игровой набор", "Детский набор машинок с героями мультсериала «Щенячий патруль» подойдет как для мальчиков, так и для девочек. В детский набор входит 9 фигурок щенков спасателей.", 22, "ABSпластик", "Детский игровой набор машинок Щенячий патруль / Dogs mini . 9 героев + 9 инерфионных машинок", "1.jpg", 1414m, 50, "Pikeshop", "шт." },
                    { 2, "BPV4MM", "Конструктор", "Коллекционная модель Букля состоит из множества потрясающих элементов, а также специального механизма внутри. С его помощью можно плавно поднимать-опускать крылья птицы.", 15, "ABSпластик", "Конструктор Гарри Поттер Сова Букля 630 деталей совместим с lego harry potter, лего совместимый)", "2.jpg", 771m, 26, "Playbig", "шт." }
                });

            migrationBuilder.InsertData(
                table: "products",
                columns: new[] { "id", "article", "category", "description", "discount", "manufacturer", "name", "photo_url", "price", "supplier", "unit" },
                values: new object[] { 3, "JVL42J", "Детский музыкальный инструмент", "Откройте мир музыки для вашего ребенка с этой уникальной игрушкой! Это многофункциональное музыкальное чудо объединяет в себе всё, что нужно для творческого развития.", 15, "BambiniFelici", "Музыкальные инструменты для детей, ксилофон, барабаны, развивающие игрушки, игрушки для детей", "3.jpg", 2750m, "Playbig", "шт." });

            migrationBuilder.InsertData(
                table: "products",
                columns: new[] { "id", "article", "category", "description", "discount", "manufacturer", "name", "photo_url", "price", "stock_quantity", "supplier", "unit" },
                values: new object[,]
                {
                    { 4, "F895RB", "Машинка", "Светящаяся музыкальная машина с диско шаром переливается разными цветами, играет ритмичные мелодии, объезжает препятствия и крутится, поэтому с ней точно не будет скучно.", 6, "ABSпластик", "Машинка игрушка диско шар светящаяся музыкальная", "4.jpg", 368m, 7, "Knauf", "шт." },
                    { 5, "3XBOTN", "Игровой набор", "Игровой набор Hot Wheels Action Loop Cyclone Challenge Track - это уникальная игра, которая позволит вам испытать себя и своих друзей в скорости и ловкости. Этот набор состоит из металлической дорожки с циклоном, которая создает потрясающий эффект и добавляет дополнительную сложность в игру.", 10, "BambiniFelici", "Игровой набор Hot Wheels Action Loop Cyclone Challenge Track, с машинкой и удобным хранением, HTK16", "5.jpg", 3426m, 21, "Knauf", "шт." }
                });

            migrationBuilder.InsertData(
                table: "products",
                columns: new[] { "id", "article", "category", "description", "discount", "manufacturer", "name", "photo_url", "price", "supplier", "unit" },
                values: new object[] { 6, "3L7RCZ", "Игровой набор", "Игровой набор «Стройплощадка Кран-Паркс Junion» — это большая игрушечная парковка с деревянными машинками и настоящим подъёмным краном, придуманная в Яндексе настоящими родителями.", 15, "Junion", "Игровой набор с деревянными машинками Стройплощадка Кран-Паркс, Junion", "6.jpg", 7400m, "Knauf", "шт." });

            migrationBuilder.InsertData(
                table: "products",
                columns: new[] { "id", "article", "category", "description", "discount", "manufacturer", "name", "photo_url", "price", "stock_quantity", "supplier", "unit" },
                values: new object[,]
                {
                    { 7, "S72AM3", "Детский музыкальный инструмент", "Откройте для ребенка дверь в мир музыки с детским синтезатором! Этот компактный инструмент с микрофоном станет верным другом для юных музыкантов, помогая им развивать творческий потенциал и получать удовольствие от игры.", 10, "Junion", "Синтезатор детский с микрофоном 61 клавиша", "7.jpg", 1749m, 35, "CHILITOY", "шт." },
                    { 8, "2G3280", "Игровой набор", "Игровой набор «Стройплощадка Кран-Паркс Junion» — это большая игрушечная парковка с деревянными машинками и настоящим подъёмным краном, придуманная в Яндексе настоящими родителями.", 9, "Junion", "Деревянный игровой набор JUNION Стройплощадка \"Кран-Паркс\" с подъёмным, строительным краном и машинками, 18 предметов, подвижные элементы", "8.jpg", 1624m, 20, "Vinylon", "шт." },
                    { 9, "MIO8YV", "Детский музыкальный инструмент", "Музыкальная игрушка интерактивная Пульт, детский прорезыватель для малышей", 9, "BambiniFelici", "Музыкальная игрушка интерактивная Пульт, детский прорезыватель для малышей", "9.jpg", 305m, 31, "Vinylon", "шт." },
                    { 10, "UER2QD", "Игровой набор", "Большой набор опытов и экспериментов для детей 14 в 1", 8, "BambiniFelici", "Большой набор опытов и экспериментов для детей 14 в 1", "10.jpg", 2506m, 27, "Vinylon", "шт." }
                });

            migrationBuilder.InsertData(
                table: "users",
                columns: new[] { "id", "created_at", "full_name", "login", "password", "role" },
                values: new object[,]
                {
                    { 1, new DateTime(2026, 5, 18, 16, 48, 55, 675, DateTimeKind.Utc).AddTicks(6811), "Ворсин Петр Евгеньевич", "94d5ous@gmail.com", "uzWC67", "admin" },
                    { 2, new DateTime(2026, 5, 18, 16, 48, 55, 675, DateTimeKind.Utc).AddTicks(6814), "Старикова Елена Павловна", "uth4iz@mail.com", "2L6KZG", "admin" },
                    { 3, new DateTime(2026, 5, 18, 16, 48, 55, 675, DateTimeKind.Utc).AddTicks(6816), "Одинцов Серафим Артёмович", "yzls62@outlook.com", "JlFRCZ", "admin" },
                    { 4, new DateTime(2026, 5, 18, 16, 48, 55, 675, DateTimeKind.Utc).AddTicks(6818), "Михайлюк Анна Вячеславовна", "1diph5e@tutanota.com", "8ntwUp", "manager" },
                    { 5, new DateTime(2026, 5, 18, 16, 48, 55, 675, DateTimeKind.Utc).AddTicks(6820), "Ситдикова Елена Анатольевна", "tjde7c@yahoo.com", "YOyhfR", "manager" },
                    { 6, new DateTime(2026, 5, 18, 16, 48, 55, 675, DateTimeKind.Utc).AddTicks(6822), "Никифорова Весения Николаевна", "wpmrc3do@tutanota.com", "RSbvHv", "manager" },
                    { 7, new DateTime(2026, 5, 18, 16, 48, 55, 675, DateTimeKind.Utc).AddTicks(6824), "Степанов Михаил Артёмович", "5d4zbu@tutanota.com", "rwVDh9", "client" },
                    { 8, new DateTime(2026, 5, 18, 16, 48, 55, 675, DateTimeKind.Utc).AddTicks(6825), "Ворсин Петр Евгеньевич", "ptec8ym@yahoo.com", "LdNyos", "client" },
                    { 9, new DateTime(2026, 5, 18, 16, 48, 55, 675, DateTimeKind.Utc).AddTicks(6827), "Старикова Елена Павловна", "1qz4kw@mail.com", "gynQMT", "client" },
                    { 10, new DateTime(2026, 5, 18, 16, 48, 55, 675, DateTimeKind.Utc).AddTicks(6829), "Сазонов Руслан Германович", "4np6se@mail.com", "AtnDjr", "client" }
                });

            migrationBuilder.InsertData(
                table: "orders",
                columns: new[] { "id", "client_full_name", "delivery_date", "order_date", "order_number", "pickup_code", "pickup_point_id", "status" },
                values: new object[,]
                {
                    { 1, "Степанов Михаил Артёмович", new DateTime(2025, 4, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2025, 2, 27, 0, 0, 0, 0, DateTimeKind.Unspecified), "1", "901", 1, "Завершен" },
                    { 2, "Ворсин Петр Евгеньевич", new DateTime(2025, 4, 21, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2024, 9, 28, 0, 0, 0, 0, DateTimeKind.Unspecified), "2", "902", 11, "Завершен" },
                    { 3, "Старикова Елена Павловна", new DateTime(2025, 4, 22, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2025, 3, 21, 0, 0, 0, 0, DateTimeKind.Unspecified), "3", "903", 2, "Завершен" },
                    { 4, "Сазонов Руслан Германович", new DateTime(2025, 4, 23, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2025, 2, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), "4", "904", 11, "Завершен" },
                    { 5, "Степанов Михаил Артёмович", new DateTime(2025, 4, 24, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2025, 3, 17, 0, 0, 0, 0, DateTimeKind.Unspecified), "5", "905", 2, "Завершен" },
                    { 6, "Ворсин Петр Евгеньевич", new DateTime(2025, 4, 25, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2025, 3, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "6", "906", 15, "Завершен" },
                    { 7, "Старикова Елена Павловна", new DateTime(2025, 4, 26, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2025, 2, 28, 0, 0, 0, 0, DateTimeKind.Unspecified), "7", "907", 3, "Завершен" },
                    { 8, "Сазонов Руслан Германович", new DateTime(2025, 4, 27, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2025, 3, 31, 0, 0, 0, 0, DateTimeKind.Unspecified), "8", "908", 19, "Новый" },
                    { 9, "Старикова Елена Павловна", new DateTime(2025, 4, 28, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2025, 4, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), "9", "909", 5, "Новый" },
                    { 10, "Сазонов Руслан Германович", new DateTime(2025, 4, 29, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2025, 4, 3, 0, 0, 0, 0, DateTimeKind.Unspecified), "10", "910", 19, "Новый" }
                });

            migrationBuilder.InsertData(
                table: "order_items",
                columns: new[] { "id", "order_id", "product_article", "quantity" },
                values: new object[,]
                {
                    { 1, 1, "PMEZMH", 2 },
                    { 2, 1, "BPV4MM", 2 },
                    { 3, 2, "JVL42J", 1 },
                    { 4, 2, "F895RB", 1 },
                    { 5, 3, "3XBOTN", 10 },
                    { 6, 3, "3L7RCZ", 10 },
                    { 7, 4, "S72AM3", 5 },
                    { 8, 4, "2G3280", 4 },
                    { 9, 5, "MIO8YV", 2 },
                    { 10, 5, "UER2QD", 2 },
                    { 11, 6, "PMEZMH", 2 },
                    { 12, 6, "BPV4MM", 2 },
                    { 13, 7, "JVL42J", 1 },
                    { 14, 7, "F895RB", 1 },
                    { 15, 8, "3XBOTN", 10 },
                    { 16, 8, "3L7RCZ", 10 },
                    { 17, 9, "S72AM3", 5 },
                    { 18, 9, "2G3280", 4 },
                    { 19, 10, "MIO8YV", 2 },
                    { 20, 10, "UER2QD", 2 }
                });

            migrationBuilder.CreateIndex(
                name: "ix_order_items_order_id",
                table: "order_items",
                column: "order_id");

            migrationBuilder.CreateIndex(
                name: "ix_order_items_product_article",
                table: "order_items",
                column: "product_article");

            migrationBuilder.CreateIndex(
                name: "ix_orders_order_number",
                table: "orders",
                column: "order_number",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_orders_pickup_point_id",
                table: "orders",
                column: "pickup_point_id");

            migrationBuilder.CreateIndex(
                name: "ix_products_article",
                table: "products",
                column: "article",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_users_login",
                table: "users",
                column: "login",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "order_items");

            migrationBuilder.DropTable(
                name: "users");

            migrationBuilder.DropTable(
                name: "orders");

            migrationBuilder.DropTable(
                name: "products");

            migrationBuilder.DropTable(
                name: "pickup_points");
        }
    }
}
